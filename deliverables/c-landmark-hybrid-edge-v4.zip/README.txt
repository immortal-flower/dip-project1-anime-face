C landmark hybrid edge v4

Contents are the frozen C landmark model only; Manga109 and AnimeFace images are not included.
Extract the model directory and use scripts/annotate_manga109_landmarks.py with Manga109 official face boxes.
Selection used AnimeFace validation only. See docs/C_MANGA109_ORACLE_LANDMARKS.md.
